"""This Module contains implementations for
Common Preprocess functions. Some functions are further
divided into various backend-dependent implementations.
"""
