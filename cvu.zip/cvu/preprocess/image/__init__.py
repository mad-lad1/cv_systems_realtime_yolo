"""This Module contains implementations for
Common Preprocess functions applied directly on images.
Some functions are further divided into various backend-dependent
implementations.
"""
