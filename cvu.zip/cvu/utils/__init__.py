"""This Module contains implementations for
Common Utilitiy functions. Some functions are further
divided into various backend-dependent implementations.
"""
