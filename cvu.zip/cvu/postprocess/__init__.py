"""This Module contains implementations for
Common Postprocessing functions. Some functions are further
divided into various backend-dependent implementations.
"""
