"""This module contains numpy implementations of various NMS.
"""
from .basic import nms_np
