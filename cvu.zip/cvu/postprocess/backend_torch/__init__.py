"""This Module contains implementations for
Common Postprocessing functions in Torch.
"""
