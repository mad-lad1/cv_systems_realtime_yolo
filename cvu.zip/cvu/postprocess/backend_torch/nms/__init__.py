"""This module contains Torch implementations of various NMS.
"""
