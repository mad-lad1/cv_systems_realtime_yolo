"""This module contains interface definitions for
various cvu-components.
"""
